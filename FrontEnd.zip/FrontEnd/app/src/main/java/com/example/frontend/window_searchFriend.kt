package com.example.frontend

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class window_searchFriend : AppCompatActivity() {

    lateinit var userIdFriend : EditText
    lateinit var userNameFriend : EditText
    lateinit var userLastNameFriend : EditText
    lateinit var userBoletaFriend : EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_window_search_friend)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        userIdFriend = findViewById(R.id.busquedaID_Input)
        userNameFriend = findViewById(R.id.busquedaNombre_Input)
        userLastNameFriend = findViewById(R.id.busquedaApellido_Input)
        userBoletaFriend = findViewById(R.id.busquedaBoleta_Input)


    }
}