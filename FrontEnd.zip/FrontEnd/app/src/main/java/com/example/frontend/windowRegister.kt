package com.example.frontend

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class windowRegister : AppCompatActivity() {


    lateinit var userNameRegister_Input : EditText
    lateinit var userLastNameRegister_Input : EditText
    lateinit var ageRegister_Input : EditText
    lateinit var carrerRegister_Input : EditText
    lateinit var boletaRegister_Input : EditText
    lateinit var emailRegister_Input : EditText
    lateinit var passwrodRegister_Input : EditText
    lateinit var passwrodComparationRegister_Input : EditText


    lateinit var registerIntoBtn : Button
    lateinit var registerBackBtn : Button


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_window_register)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        userNameRegister_Input = findViewById(R.id.registroNombre_Input)
        userLastNameRegister_Input = findViewById(R.id.registroApellido_Input)
        ageRegister_Input = findViewById(R.id.registroEdad_Input)
        carrerRegister_Input = findViewById(R.id.registroEspecialidad_Input)
        boletaRegister_Input = findViewById(R.id.registroNumBoleta_Input)
        emailRegister_Input = findViewById(R.id.registroEmailAdress_Input)
        passwrodRegister_Input = findViewById(R.id.registroPassword_Input)
         passwrodComparationRegister_Input = findViewById(R.id.registroPasswordConfirmacion_Input)

        registerIntoBtn = findViewById(R.id.registroContinuarButton)
        registerBackBtn = findViewById(R.id.registroRegresarLogin_Button)




        registerIntoBtn.setOnClickListener {
            val userName_Register = userNameRegister_Input.text.toString()
            val userLastName_Register = userLastNameRegister_Input.text.toString()
            val userCarrer_Register = carrerRegister_Input.text.toString()
            val userAge_Register = ageRegister_Input.id.toString()
            val userBoleta_Register = boletaRegister_Input.text.toString()
            val userEmail_Register = emailRegister_Input.text.toString()
            val userPasword_Register = passwrodRegister_Input.text.toString()
            val userComfPasword_Register = passwrodComparationRegister_Input.text.toString()


            if (!isBoletaValid(userBoleta_Register)) {
                Toast.makeText(this, "La boleta debe tener 10 dígitos.", Toast.LENGTH_LONG).show()
            } else if (!isPasswordValid(userPasword_Register)) {
                Toast.makeText(this, "La contraseña debe tener minimo 8 caracteres, una letra y un número.", Toast.LENGTH_LONG).show()
            } else if (userPasword_Register != userComfPasword_Register) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_LONG).show()
            } else {

                val randomNumber = generateRandomNumber()
                Log.i("Test register", "Generated Random Number: $randomNumber")
                Toast.makeText(this, "Usuario registrado con éxito. Número generado: $randomNumber", Toast.LENGTH_LONG).show()


                val intent: Intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }


            Log.i("Test register", "Username: $userName_Register yor last Name :$userLastName_Register the age is :$userAge_Register boleta number : $userBoleta_Register")


        }

        registerBackBtn.setOnClickListener {
            val intent: Intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }

    
    private fun isPasswordValid(password: String): Boolean {
        val passwordPattern = Regex("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$")
        return password.matches(passwordPattern)
    }
    private fun isBoletaValid(boleta: String): Boolean {
        val boletaPattern = Regex("^\\d{10}$")
        return boleta.matches(boletaPattern)
    }

    private fun generateRandomNumber(): String {
        return (0..1)
            .map { Random.nextInt(0, 20) }
            .joinToString("")
    }
}