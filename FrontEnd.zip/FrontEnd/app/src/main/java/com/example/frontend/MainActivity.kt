package com.example.frontend

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    lateinit var userEmailInput : EditText
    lateinit var userPasswordInput : EditText
    lateinit var BoletaNameInput : EditText
    lateinit var loginBtn : Button
    lateinit var registerBtn : Button


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        userEmailInput = findViewById(R.id.userEmail_Input)
        userPasswordInput = findViewById(R.id.password_Input)
        BoletaNameInput = findViewById(R.id.boleta_Input)

        loginBtn = findViewById(R.id.into_Btn)
        registerBtn = findViewById(R.id.register_Btn)




        loginBtn.setOnClickListener{
            val user = userEmailInput.text.toString()
            val passwordUser = userPasswordInput.text.toString()
            val boletaUser = BoletaNameInput.text.toString()


            Log.i("Test Credentials","Username: $user password $passwordUser boleta $boletaUser")


        }

        registerBtn.setOnClickListener {
            val intent: Intent = Intent(this, windowRegister::class.java)
            startActivity(intent)
        }
    }
}